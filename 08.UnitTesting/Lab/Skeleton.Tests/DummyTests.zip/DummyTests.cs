﻿using NUnit.Framework;

namespace Skeleton.Tests
{
    [TestFixture]
    public class DummyTests
    {
        [Test]
        public void DummyShouldLoseHealthWhenAttacked()
        {
            Dummy dummy = new Dummy(100, 10);
            int weaponAttackPoints = 20;

            dummy.TakeAttack(weaponAttackPoints);

            Assert.That(100 - weaponAttackPoints, Is.EqualTo(dummy.Health));
        }

        [Test]
        public void AttackOnDeadDummyShouldThrowException()
        {
            Dummy dummy = new Dummy(0, 10);

            Assert.Catch(() =>
            {
                dummy.TakeAttack(1);
            });
        }

        [Test]
        public void DeadDummyCanGiveExperience()
        {
            Dummy dummy = new Dummy(0, 10);

            Assert.That(10, Is.EqualTo(dummy.GiveExperience()));
        }

        [Test]
        public void AliveDummyCannotGiveExperience()
        {
            Dummy dummy = new Dummy(100, 10);

            Assert.Catch(() =>
            {
                dummy.GiveExperience();
            });
        }
    }
}