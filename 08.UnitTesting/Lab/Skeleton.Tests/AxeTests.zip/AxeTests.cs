using NUnit.Framework;
using System;

namespace Skeleton.Tests
{
    public class AxeTests
    {
        [Test]
        public void AxeShouldLoseDurabilityAfterAttack()
        {
            int axeDurability = 10;
            Axe axe = new Axe(20, axeDurability);

            axe.Attack(new Dummy(100, 10));

            Assert.AreEqual(axeDurability - 1, axe.DurabilityPoints);
        }

        [Test]
        public void AttackingWithBrokenAxeShouldThrowException()
        {
            int axeDurability = 0;
            Axe axe = new Axe(20, axeDurability);
            Dummy dummy = new Dummy(100, 10);

            Assert.Catch(() =>
            {
                axe.Attack(dummy);
            });
        }
    }
}