﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P05.BirthdayCelebrations
{
    public interface IIdentifiable
    {
        string Id { get; set; }
    }
}
