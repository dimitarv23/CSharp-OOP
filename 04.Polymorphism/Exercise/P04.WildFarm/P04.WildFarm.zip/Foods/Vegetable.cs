﻿using System;
using System.Collections.Generic;
using System.Text;
using P04.WildFarm.Models;

namespace P04.WildFarm.Foods
{
    public class Vegetable : Food
    {
        public Vegetable(int quantity) : base(quantity)
        {
        }
    }
}
