﻿using System;
using System.Collections.Generic;
using System.Text;
using P04.WildFarm.Models;

namespace P04.WildFarm.Foods
{
    public class Meat : Food
    {
        public Meat(int quantity) : base(quantity)
        {
        }
    }
}
