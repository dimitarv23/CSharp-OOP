﻿namespace PlanetWars.Models.MilitaryUnits.Entities
{
    public class AnonymousImpactUnit : MilitaryUnit
    {
        public AnonymousImpactUnit() : base(30)
        {
        }
    }
}
