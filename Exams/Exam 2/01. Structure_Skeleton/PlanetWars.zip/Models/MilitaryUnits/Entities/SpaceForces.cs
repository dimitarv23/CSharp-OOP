﻿namespace PlanetWars.Models.MilitaryUnits.Entities
{
    public class SpaceForces : MilitaryUnit
    {
        public SpaceForces() : base(11)
        {
        }
    }
}
