﻿namespace PlanetWars.Models.MilitaryUnits.Entities
{
    public class StormTroopers : MilitaryUnit
    {
        public StormTroopers() : base(2.5)
        {
        }
    }
}
