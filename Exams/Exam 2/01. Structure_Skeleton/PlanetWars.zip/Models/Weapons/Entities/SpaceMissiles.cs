﻿namespace PlanetWars.Models.Weapons.Entities
{
    public class SpaceMissiles : Weapon
    {
        public SpaceMissiles(int destructionLevel) : base(destructionLevel, 8.75)
        {
        }
    }
}
